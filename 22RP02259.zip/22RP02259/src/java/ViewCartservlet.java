import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/view-cart"})
public class ViewCartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // HTML content starts here
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>View Cart</title>");
        out.println("<style>");
        out.println("body { font-family: 'Helvetica Neue', sans-serif; background-color: #eaeaea; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }");
        out.println(".container { background: #ffffff; padding: 30px; border-radius: 12px; box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); text-align: center; max-width: 600px; width: 100%; }");
        out.println("h1 { color: #007bff; font-size: 2.2em; margin-bottom: 30px; }");
        out.println("p { margin: 15px 0; font-size: 1.1em; color: #333; }");
        out.println("form { margin: 15px 0; }");
        out.println("button { background-color: #007bff; color: white; padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 1.1em; transition: background-color 0.3s, transform 0.2s; }");
        out.println("button:hover { background-color: #0056b3; transform: scale(1.05); }");
        out.println("a { display: block; margin-top: 30px; text-decoration: none; color: #007bff; font-size: 1.1em; transition: color 0.3s; }");
        out.println("a:hover { color: #0056b3; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h1>Your Cart</h1>");

        Cookie[] cookies = request.getCookies();
        boolean cartEmpty = true;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("cart".equals(cookie.getName())) {
                    ArrayList<String> cartItems = new ArrayList<>(Arrays.asList(URLDecoder.decode(cookie.getValue(), "UTF-8").split(",")));
                    for (String item : cartItems) {
                        out.println("<p>" + item + "</p>");
                        out.println("<form action='remove-item' method='post'>");
                        out.println("<input type='hidden' name='item' value='" + item + "'>");
                        out.println("<button type='submit'>Remove</button>");
                        out.println("</form>");
                    }
                    cartEmpty = false;
                }
            }
        }
        if (cartEmpty) {
            out.println("<p>Your cart is currently empty.</p>");
        }
        out.println("<a href='index.html'>Continue Shopping</a>");
        out.println("<form action='clear-cart' method='post'>");
        out.println("<button type='submit'>Clear Cart</button>");
        out.println("</form>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
